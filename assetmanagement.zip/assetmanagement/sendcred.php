<?php
// Receive username and password from dashboard.php
$username = $_POST['username'];
$password = $_POST['password'];

// Save the username and password in the database or send them to the user
// ...

// Redirect the user to the about.php page with the username and password
header("Location: contact.php?username=$username&password=$password");
exit();