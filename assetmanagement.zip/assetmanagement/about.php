<!DOCTYPE html>
<html>
    <head>
        <title>asset-management</title>
       <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/.css">
        <?php
        ?>
        <style>
    .main{
    height: 600px;
    width: 100%;
      }
            .cont{
    background-image: url(wolita.png);
    background-repeat: no-repeat;
    background-size: cover;    
    width: 56%;
    height: 100%;
    border: 1px solid blue;
    float: left;
}
.side{
    width: 43%;
    height: 100%;
    border: 1px solid blue;
    float: right;
    background: #035356;
    color: white;
}
.mennu{
    border: 1px solid green;
    list-style: none;
    background-color:#035356;
    color:rgb(22, 113, 193);
    text-decoration: none;
    height:100px;
    width: calc(100%);
}
.foter{
    border: 1px solid red;
    background: blueviolet;
     color: white;
        height: 43px;
        width: calc(100%);
    }
    .mennu li{
        text-align: center;
        width: 80px;
        height: 20px;
        margin-top: 20px;
        margin-left: 4%;
        text-decoration: white;
        display:inline-flex;
        border: 1px solid greenyellow;
        background-color: black;
    }
    .mennu a{
        text-align: center;
        text-decoration: none;
        color: white;
    }
        </style>
    </head>
    <div class="mennu">
        <ul>
            <?php
           if(isset($_SESSION['id'])){
            ?>
            
            <?php
           }else{
            ?>
            <li><a href="http://localhost/assetmanagement/index.php">Home</a></li>
            <?php
           }
           ?>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <?php
            if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/asset/lists.php">Assetlist</a></li>
            <li><a href="http://localhost/assetmanagement/aboout.php">About</a></li>
            <li><a href="http://localhost/assetmanagement/contact.php">Contact</a></li>
            <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
            <?php
             }else{
                ?>
                <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
            <?php
        }
        ?>
        </ul>
    </div>
    <div class="main">
        <div class="cont" >
            <h2>This is About page</h2>
        </div>
        <div class="side">
       <h1 style="color:white;"> Welcome to the Wolayita Sodo University Asset Management system!</h1> <br>
        <h4> Our cutting-edge system is designed to efficiently manage a wide range of assets,
          <br>including cars, buildings, bridges, asphalt and roads, furniture, healthcare materials, and papers.
           <br> With our innovative platform, we provide a comprehensive solution for tracking, maintaining,<br>
         and optimizing the university's valuable assets. <br>
Our system utilizes advanced technology to streamline asset management processes, <br> 
ensuring that resources are utilized effectively and maintained to the highest standards.  <br>
<br> From tracking the maintenance schedules of vehicles to monitoring the condition of buildings <br> 
and infrastructure, our system offers a holistic approach to asset management. <br>
With a user-friendly interface and robust features, our Asset Management System  <br>
empowers administrators to make informed decisions about asset allocation, maintenance priorities, <br>
 and resource optimization. By centralizing asset data and providing real-time insights, <br>
  we enable the university to maximize the value of its assets and enhance operational efficiency. <br>
Join us on this exciting journey as we revolutionize asset management at Wolayita Sodo University <br>
 and pave the way for a more sustainable and efficient future. <br></h4>
 Let's unlock the full potential of our assets together!
        </div> 
    </div>
    <div class="foter">foter hee</div>
    </body>
</html>