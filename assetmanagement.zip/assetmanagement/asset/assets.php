
<!DOCTYPE html>
<html>
    <head>
        <title>Assets Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="../css/.css">
        <?php
        session_start();
        ?>
        <style>
body{
    height: 100%;
    width: 100%;
}
.logoo{
    width: 100%;
    height:70px;
   border: 1px solid blue; 
   background-color:#035356;
   color: black;
   text-align: top;
}
.mennu{
    border: 1px solid green;
    list-style: none;
    background-color:#035356;
    color:aliceblue;
    text-align: calc(60% top);
    height:50px;
    width: calc(100%);
}
.mennu li{
    text-align: center;
    width: 80px;
    height: 20px;
    margin-left: 15%;
    text-decoration: white;
    display:inline-flex;
    border: 1px solid greenyellow;
    background-color: black;
}
.mennu a{
    text-align: center;
    text-decoration: none;
    color: white;
}
            .maiin{
    height:480px;
    background-color: rgba(2, 0,5,0.905);
    color:white;
            }
.cont{
   width: 45%;
    height: 479px;
    border: none;
    float: left;
    color: white;
    text-align: center;
}

.sidee{
    width:50%;
    height: 450px;
    border:none;
    float: right;
    color: white;
}
.add{
    padding-left:40%;
}
.foter{
border: 1px solid red;
background: blueviolet;
 color: white;
    height:50px ;
    width: calc(100%);
}            /* Your existing CSS styles */
        </style>
    </head>
    <body>
        <div class="logoo">
            <marquee direction="left/right"><h1><a href="http://localhost/assetmanagement" style="color:white">WELCOME TO ADD ASSET PAGE</a></h1></marquee>
        </div>
        <div class="mennu">
            <ul>
                <?php
                if(isset($_SESSION['id'])){
                    if($_SESSION['role']=='admin'){
                        ?>
                        <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
                        <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
                        <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
                        <?php
                    }
                }else{
                    ?>
                    <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
                    <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <div class="maiin">
            <?php
            if(isset($_SESSION['id'])){
                if($_SESSION['role']=='admin'){
                    ?>
                    <form action="assets.php" method="post" enctype="multipart/form-data">
                        <div class="cont">
                            <p>Asset name</p><input type="text" name="assetname">
                            <p>Category</p><input type="text" name="cat">
                            <p>Type</p><input type="text" name="type">
                            <p>Location</p><input type="text" name="location">
                            <p>Asset Price</p><input type="text" name="price">
                        </div>
                        <div class="sidee">
                            <p>Usage Life</p><input type="text" name="usagelife">
                            <p>Register Date</p><input type="date" name="startdate">
                            <p>Disposal Date</p><input type="date" name="disposaldate"><br><br>
                            <p>Image</p><input type="file" name="image">
                        </div><br><br><br>
                        <div class="add">
                            <input type="submit" name="addasset" value="Add Asset">
                        </div>
                    </form>
                    <?php
                    include('../include/users/db.php');
                    if(isset($con)){
                        if(isset($_POST['addasset'])){
                            $assetname=$_POST['assetname'];
                            $cat=$_POST['cat'];
                            $type=$_POST['type'];
                            $location=$_POST['location'];
                            $price=$_POST['price'];
                            $usagelife=$_POST['usagelife'];
                            $startdate=$_POST['startdate'];
                            $disposaldate=$_POST['disposaldate'];
                            $target="image/".basename($_FILES['image']['name']);
                            $image=$_FILES['image']['name'];
                            $sql="INSERT INTO asset(assetname,cat,type,location,price,usagelife,startdate,disposaldate,image) VALUES('$assetname','$cat','$type','$location','$price','$usagelife','$startdate','$disposaldate','$image')";

$exc=mysqli_query($con, $sql);
                            if(isset($exc) && copy($_FILES['image']['tmp_name'], $target)){
                                echo "Asset Added";
                            }else{
                                echo "Something went wrong";
                            }
                        }
                    }
                    ?>
                    
<?php
                }
            }else{
                echo "You are not authorized to access this page.";
            }
            ?>
           <h1><a href="http://localhost/assetmanagement/asset/viewasset.php" style="color:white">View delete update</a></h1> 
        </div>
    </body>
</html>