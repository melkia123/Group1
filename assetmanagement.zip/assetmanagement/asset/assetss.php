<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> PHP CRUD with Bootstrap Modal </title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <style>
        .mennu{
    list-style: none;
    background-color:#035356;
    color:aliceblue;
    text-align: calc(5% top);
    height:90px;
    width: calc(100%);
}
body{
    background-image: url(photo11.jpg);
}
.container{
    margin-top:40px;
    margin-bottom:40px;
}
.mennu li{
    text-align: center;
    width: 80px;
    height: 40px;
    margin-top:40px;
    margin-left: 15%;
    text-decoration: white;
    display:inline-flex;
    border: 1px solid greenyellow;
    background-color: black;
}
.mennu a{
    text-align: center;
    text-decoration: none;
    color: white;
}
            .maiin{
    height:520px;
    background-color: green;
    color:white;
    background-image: url(photo11.jpg);
            }
.foter{
border: 1px solid red;
background: blueviolet;
 color: white;
    height:90px ;
    width: calc(100%);
}
    </style>
</head>
<body>
<div class="mennu">
        <ul>
    
            <?php
        
           ?>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
            <?php
            if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
            <?php
             }else{
                ?>
            
            </ul>
            </div>
            <?php
        }
        ?>
        </ul>
    </div>
    
<?php
session_start();
?>
    <!-- Modal -->
    <div class="modal fade" id="studentaddmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">craete account</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="addasset.php" method="POST">

                    <div class="modal-body">
                        <div class="form-group">
                            <label> AssetName </label>
                            <input type="text" name="assetname" class="form-control" placeholder="Enter First Name">
                        </div>

                        <div class="form-group">
                            <label> Catagory</label>
                            <input type="text" name="cat" class="form-control" placeholder="Enter Last Name">
                        </div>

                        <div class="form-group">
                            <label> Location</label>
                            <input type="text" name="location" class="form-control" placeholder="Enter Email">
                        </div>

                        <div class="form-group">
                            <label> Price </label>
                            <input type="text" name="price" class="form-control" placeholder="Enter Phone Number">
                        </div>
                        <div class="form-group">
                            <label> UsageLife</label>
                            <input type="text" name="usagelife" class="form-control" placeholder="Enter Password">
                        </div>
                        <div class="form-group">
                            <label> StartDate</label>
                            <input type="date" name="startdate" class="form-control" placeholder="Enter Password">
                        </div>
                        <div class="form-group">
                            <label> DisposalDate</label>
                            <input type="date" name="disposaldate" class="form-control" placeholder="Enter Password">
                        </div>
                        <div class="form-group">
                            <label> Image</label>
                            <input type="file" name="image" class="form-control" placeholder="Enter Password">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="addasset" class="btn btn-primary">save info</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <!-- EDIT POP UP FORM (Bootstrap MODAL) -->
    <div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Edit user Data </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="editasset.php" method="POST">

                    <div class="modal-body">

                        <input type="hidden" name="update_id" id="update_id">

                        <div class="form-group">
                            <label> AssetName </label>
                            <input type="text" name="assetname" id="assetname" class="form-control"
                                placeholder="Enter First Name">
                        </div>

                        <div class="form-group">
                            <label> Catagory </label>
                            <input type="text" name="cat" id="cat" class="form-control"
                                placeholder="Enter Last Name">
                        </div>

                        <div class="form-group">
                            <label> Location </label>
                            <input type="text" name="location" id="course" class="form-control"
                            >
                        </div>

                        <div class="form-group">
                            <label> Price </label>
                            <input type="text" name="price" id="contact" class="form-control"
                        >
                        </div>
                        <div class="form-group">
                            <label> UsageLife </label>
                            <input type="text" name="usaglife" id="contact" class="form-control"
                            >
                        </div>
                        <div class="form-group">
                            <label> StartDate </label>
                            <input type="date" name="startdate" id="contact" class="form-control"
                            >
                        </div>
                        <div class="form-group">
                            <label> DisposalDate </label>
                            <input type="date" name="disposaldate" id="contact" class="form-control"
                            >
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="updatedata" class="btn btn-primary">Update Data</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
<!-- VIEW POP UP FORM (Bootstrap MODAL) -->
<div class="modal fade" id="viiewmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"> View User Data </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="view.php" method="POST">

                <div class="modal-body">

                    <input type="hidden" name="view_id" id="view_id">

                    <div class="form-group">
                        <label>AssetName </label>
                        <input type="text" name="assetname" id="view_assetname" class="form-control" disabled>
                    </div>

                    <div class="form-group">
                        <label> Catagory </label>
                        <input type="text" name="cat" id="view_cat" class="form-control" disabled>
                    </div>

                    <div class="form-group">
                        <label> Location </label>
                        <input type="text" name="location" id="view_location" class="form-control" disabled>
                    </div>

                    <div class="form-group">
                        <label> Price</label>
                        <input type="text" name="price" id="view_price" class="form-control" disabled>
                    </div>

                    <div class="form-group">
                        <label> UsageLife </label>
                        <input type="text" name="usagelife" id="view_usagelife" class="form-control" disabled>
                    </div>
                    <div class="form-group">
                        <label> StartDate </label>
                        <input type="date" name="startdate" id="view_startdate" class="form-control" disabled>
                    </div>

                    <div class="form-group">
                        <label> DisposalDate </label>
                        <input type="date" name="disposaldate" id="view_disposaldate" class="form-control" disabled>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" name="view_id" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>

            </form>

        </div>
    </div>
</div>
    <!-- DELETE POP UP FORM (Bootstrap MODAL) -->
    <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Delete User Data </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="deleteasset.php" method="POST">

                    <div class="modal-body">

                        <input type="hidden" name="delete_id" id="delete_id">

                        <h4> Do you want to Delete this Data ??</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
                        <button type="submit" name="deletedata" class="btn btn-primary"> Yes !! Delete it. </button>
                    </div>
                </form>

            </div>
        </div>
    </div>


    <!-- VIEW POP UP FORM (Bootstrap MODAL) -->
    <div class="modal fade" id="viewmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> View User Data </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        
                    </button>
                </div>

                <form action="view.php" method="POST">

                    <div class="modal-body">

                        <input type="text" name="view_id" id="view_id">

                        <!-- <p id="fname"> </p> -->
                        <h4 id="assetname"> <?php echo ''; ?> </h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> CLOSE </button>
                        <!-- <button type="submit" name="deletedata" class="btn btn-primary"> Yes !! Delete it. </button> -->
                    </div>
                </form>

            </div>
        </div>
    </div>
    <div class="container">
            <div class="card">
            <h4 style="color:black;text-align:center;"> ALL ABOUT ASSET USERS </h4>
            </div>
            <div class="card">
                <div class="card-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#studentaddmodal">
                        Create Users Account
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">

                    <?php
                include('../include/users/db.php');

                $query = "SELECT * FROM asset";
                $query_run = mysqli_query($con, $query);
            ?>
                    <table id="datatableid" class="table table-bordered table-dark">
                        <thead>
                            <tr>
                                <th scope="col"> ID</th>
                                <th scope="col">AssetName</th>
                                <th scope="col">Catagory </th>
                                <th scope="col"> Location</th>
                                <th scope="col"> Price </th>
                                <th scope="col"> UsageLife </th>
                                <th scope="col"> StartDate </th>
                                <th scope="col"> DisposalDate</th>
                                <th scope="col"> VIEW </th>
                                <th scope="col"> EDIT </th>
                                <th scope="col"> DELETE </th>
                            </tr>
                        </thead>
                        <?php
                if($query_run)
                {
                    foreach($query_run as $row)
                    {
            ?>
                        <tbody>
                            <tr>
                                <td> <?php echo $row['id']; ?> </td>
                                <td> <?php echo $row['assetname']; ?> </td>
                                <td> <?php echo $row['cat']; ?> </td>
                                <td> <?php echo $row['location']; ?> </td>
                                <td> <?php echo $row['price']; ?> </td>
                                <td> <?php echo $row['usagelife']; ?> </td>
                                <td> <?php echo $row['disposaldate']; ?> </td>
                                <td> <?php echo $row['startdate']; ?> </td>

                                <td>
                                    <button type="button" class="btn btn-info viewbtn"> VIEW </button>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-success editbtn"> EDIT </button>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-danger deletebtn"> DELETE </button>
                                </td>
                            </tr>
                        </tbody>
                        <?php           
                    }
                }
                else 
                {
                    echo "No Record Found";
                }
            ?>
                    </table>
                </div>
            </div>


        </div>
    </div>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>


    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function () {

            $('.viewbtn').on('click', function () {
                $('#viewmodal').modal('show');
                $.ajax({ //create an ajax request to display.php
                    type: "GET",
                    url: "display.php",
                    dataType: "html", //expect html to be returned                
                    success: function (response) {
                        $("#responsecontainer").html(response);
                        //alert(response);
                    }
                });
            });

        });
    </script>


    <script>
        $(document).ready(function () {

            $('#datatableid').DataTable({
                "pagingType": "full_numbers",
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                responsive: true,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search Your Data",
                }
            });

        });
    </script>

    <script>
        $(document).ready(function () {

            $('.deletebtn').on('click', function () {

                $('#deletemodal').modal('show');

                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function () {
                    return $(this).text();
                }).get();

                console.log(data);

                $('#delete_id').val(data[0]);

            });
        });
    </script>

    <script>
        $(document).ready(function () {

            $('.editbtn').on('click', function () {

                $('#editmodal').modal('show');

                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function () {
                    return $(this).text();
                }).get();

                console.log(data);

                $('#update_id').val(data[0]);
                $('#assetname').val(data[1]);
                $('#cat').val(data[2]);
                $('#location').val(data[3]);
                $('#price').val(data[4]);
                $('#usagelife').val(data[4]);
                $('#disposaldate').val(data[4]);
                $('#startdate').val(data[4]);
            });
        });
    </script>
    <script>
    $(document).ready(function () {

        $('.viewbtn').on('click', function () {

            $('#viewmodal').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();

            console.log(data);

            $('#view_id').val(data[0]);
            $('#view_assetname').val(data[1]);
            $('#view_cat').val(data[2]);
            $('#view_location').val(data[3]);
            $('#view_price').val(data[4]);
            $('#view_usagelife').val(data[4]);
            $('#view_disposaldate').val(data[4]);
            $('#view_startdate').val(data[4]);
        });
    });
</script>
</div>
    <div class="foter">here is fo0ter</div>
</body>
</html>
