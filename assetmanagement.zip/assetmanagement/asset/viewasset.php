
<!DOCTYPE html>
<html>
<head>
    <title>Assets Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <?php
    session_start();
    ?>
    <style>
        table,tr,thead,td{
            border:2px solid black;
        }
    </style>
</head>
<body>
    <?php
    if(isset($_SESSION['id'])){
        if($_SESSION['role']=='admin'){
            ?>
            <h2>Existing Assets</h2>
            <table>
                <thead>
                    <tr>
                        <th>Asset Name</th>
                        <th>Category</th>
                        <th>Type</th>
                        <th>Location</th>
                        <th>Price</th>
                        <th>Usage Life</th>
                        <th>Start Date</th>
                        <th>Disposal Date</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include('../include/users/db.php');
                    $sql = "SELECT * FROM asset";
                    $result = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_assoc($result)){
                        ?>
                        <tr>
                            <td><?php echo $row['assetname']; ?></td>
                            <td><?php echo $row['cat']; ?></td>
                            <td><?php echo $row['type']; ?></td>
                            <td><?php echo $row['location']; ?></td>
                            <td><?php echo $row['price']; ?></td>
                            <td><?php echo $row['usagelife']; ?></td>
                            <td><?php echo $row['startdate']; ?></td>
                            <td><?php echo $row['disposaldate']; ?></td>
                            <td><img src="image/<?php echo $row['image']; ?>" width="50" height="50"></td>
                            <td>
                                <button onclick="showUpdateForm(<?php echo $row['id']; ?>)">Update</button>
                                <button onclick="deleteAsset(<?php echo $row['id']; ?>)">Delete</button>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
            <div id="update-form" style="display: none;">
                <h2>Update Asset</h2>
                <form id="update-asset-form" method="post" enctype="multipart/form-data">
                    <input type="hidden" id="asset-id" name="asset-id">
                    <p>Asset name</p><input type="text" id="asset-name" name="assetname">
                    <p>Category</p><input type="text" id="asset-category" name="cat">
                    <p>Type</p><input type="text" id="asset-type" name="type">
                    <p>Location</p><input type="text" id="asset-location" name="location">
                    <p>Asset Price</p><input type="text" id="asset-price" name="price">
                    <p>Usage Life</p><input type="text" id="asset-usage-life" name="usagelife">
                    <p>Register Date</p><input type="date" id="asset-start-date" name="startdate">
                    <p>Disposal Date</p><input type="date" id="asset-disposal-date" name="disposaldate">
                    <p>Image</p><input type="file" id="asset-image" name="image">

                    <input type="submit" name="update-asset" value="Update Asset">

</form>
            </div>
            <script>
                function showUpdateForm(assetId) {
                    // Fetch the asset data and populate the update form
                    fetch('fetch_asset.php?id=' + assetId)
                        .then(response => response.json())
                        .then(data => {
                            document.getElementById('asset-id').value = data.id;
                            document.getElementById('asset-name').value = data.assetname;
                            document.getElementById('asset-category').value = data.cat;
                            document.getElementById('asset-type').value = data.type;
                            document.getElementById('asset-location').value = data.location;
                            document.getElementById('asset-price').value = data.price;
                            document.getElementById('asset-usage-life').value = data.usagelife;
                            document.getElementById('asset-start-date').value = data.startdate;
                            document.getElementById('asset-disposal-date').value = data.disposaldate;
                            document.getElementById('update-form').style.display = 'block';
                        });
                }

                function deleteAsset(assetId) {
    // Send a delete request to the delete_asset.php file
    fetch('delete_asset.php?id=' + assetId, {
        method: 'DELETE'
    })
        .then(response => response.json())
        .then(data => {
            // Handle the response or perform any additional actions
            console.log(data);
        })
        .catch(error => {
            // Handle any errors that occur during the request
            console.error(error);
        });
}
<?php
                }
            }else{
                echo "You are not authorized to access this page.";
            }
            ?>
        </div>
    </body>
</html>