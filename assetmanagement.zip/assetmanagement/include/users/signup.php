<?php
session_start();

include('db.php');

if(isset($_SESSION['id'])){
    echo "You have already logged in";
} else {
    if(isset($_POST['signup'])){
        $fname=$_POST['fname'];
        $lname=$_POST['lname'];
        $email=$_POST['email'];
        $username=$_POST['username'];
        $password=md5($_POST['password']);
        $role=$_POST['role'];
        $sql="INSERT INTO assetusers (fname,lname,email,username,password,role) VALUES('$fname','$lname','$email','$username','$password','$role')";
        $res=mysqli_query($con,$sql);
        if(isset($res)){
            header('location:login.php');
            exit(); // Add this line to stop further execution of the code
        } else {
            echo "Failed to create account. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/sign.css">
<script type="text/javascript">
function validation() {
    var fname = document.reg.fname.value;
    var lname = document.reg.lname.value;
    var email = document.reg.email.value;
    var username = document.reg.username.value;
    var password = document.reg.password.value;
    var lettersOnlyRegex = /^[A-Za-z]+$/;
    var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var numbersOnlyRegex = /^[0-9]+$/;

    if (fname == "" || fname == null) {
        document.getElementById('fspan').innerHTML = "Please enter First Name";
        return false;
    } else if (!fname.match(lettersOnlyRegex)) {
        document.getElementById('fspan').innerHTML = "First Name should contain only letters";
        return false;
    } else if (fname.length < 5 || fname.length > 30) {
        document.getElementById('fspan').innerHTML = "First Name should be between 5 and 30 characters";
        return false;
    }

    if (lname == "" || lname == null) {
        document.getElementById('lspan').innerHTML = "Please enter Last Name";
        return false;
    } else if (!lname.match(lettersOnlyRegex)) {
        document.getElementById('lspan').innerHTML = "Last Name should contain only letters";
        return false;
    } else if (lname.length < 5 || lname.length > 30) {
        document.getElementById('lspan').innerHTML = "Last Name should be between 5 and 30 characters";
        return false;
    }

    if (email == "" || email == null) {
        document.getElementById('espan').innerHTML = "Please enter Email";
        return false;
    } else if (!email.match(emailRegex)) {
        document.getElementById('espan').innerHTML = "Please enter a valid Email";
        return false;
    }

    if (username == "" || username == null) {
        document.getElementById('uspan').innerHTML = "Please enter Username";
        return false;
    } else if (username.length < 5 || username.length > 30) {
        document.getElementById('uspan').innerHTML = "Username should be between 5 and 30 characters";
        return false;
    }

    if (password == "" || password == null) {
        document.getElementById('pspan').innerHTML = "Please enter Password";
        return false;
    } else if (!password.match(numbersOnlyRegex)) {
        document.getElementById('pspan').innerHTML = "Password should contain only numbers";
        return false;
    } else if (password.length < 5 || password.length > 100) {
        document.getElementById('pspan').innerHTML = "Password should be between 5 and 100 numbers";
        return false;
    }
}
</script>
        
        <style>
            .maiin{
            background-image:url(signup.jpg);    
            }
            body{
    height: 100%;
    width: 100%;
}
.logoo{
    width: 100%;
    height:50px;
   border: 1px solid blue; 
   background-color: #035356;
   color: black;
   text-decoration: none;
}

.maiin{
    background-color: #fff;
    height:600px;
    width: calc(100%);
    border: 2px solid black;
}
.box{
height: 500px;
width: 40%;
background-color: rgba(2, 0,5,0.905);
position: absolute;
color: #fff;
transform: translate (-50%, -50%);
left: 20%;
top:12% ;
border-radius: 30px;
}
h1{
margin: 0;
text-align: center;
font-size: 30px;
}
.form1{
    margin-left: 3%;
    margin-right: 3%;
    text-align: center;
    height: 495px;
}
.foter{
border: 1px solid red;
background: blueviolet;
 color: white;
    height: 43px;
    width: calc(100%);
}
.box input{
    width: 40%;
    margin-bottom: 3px;
    color: black;
}
.box input[type="text"],input[type="email"],input[type="password"]{
    border: none;
    border-bottom: 1px solid #fff;
    background-color: white;
    outline: none;
    height: 20px;
    border-radius: 20px;
}

.box input[type="submit"]{
    border: none;
    outline: none;
    height: 15px;
    background-color: aquamarine;
    color: black;
    border-radius: 20px;
}
.box input[type="submit"]:hover{
    cursor: pointer;
    background-color: #ffc107;
}/* Rest of your CSS code */
    </style>
</head>
<body>
    <div class="logoo">
        <marquee behavior="scroll" direction="right"><h1><a href="http://localhost/assetmanagement" style="color:white;text-align:center;">WELCOME TO SIGNUP PAGE</a></h1></marquee>
    </div>
    <div class="maiin">
        <div class="box">
            <div class="form1">
        
        <h2>Signup page</h2>
        <form method="POST" action="signup.php" name="reg" onsubmit="return validation ();">
           <label>Firs name:</label><br> <input type="text" name="fname"><br><span style="color:red;background-color:white;" id="fspan"></span><br>
           <label>Last name:</label><br><input type="text" name="lname"><br><span style="color:red;background-color:white;" id="lspan"></span><br>
           <label>Email:</label><br><input type="email" name="email"><br><span style="color:red;background-color:white;" id="espan"></span><br>
           <label>User name:</label><br><input type="text" name="username"><br><span style="color:red;background-color:white;" id="uspan"></span><br>
           <label>password:</label><br><input type="password" name="password"><br><span style="color:red;background-color:white;" id="pspan"></span>
           <label for="role">Select Role</label><br><select id="role" name="role"> 
           <option value="admin" name="role">admin</option>
           <option value="manager" name="role">manager</option></select><br><br>
            <input type="submit" name="signup" value="craete account">
            <p>have you already an acount?&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="login.php" style="color:greenyellow"> Login</a></p>
        </form>
                <!-- Rest of your form code -->
            </div>
        </div>
    </div>
    <div class="foter">here is footer</div>
</body>
</html>