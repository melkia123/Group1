<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Asset Request</title>
</head>
<body>
    <form method="post" action="askforasset.php">
        <label for="userid">User ID:</label>
        <input type="text" name="userid" id="userid" required><br>
        <input type="submit" value="Request Assets">
    </form>
</body>
</html>

<?php
include('db.php');
// Now, let's create the PHP file 'process_request.php' to handle the user's request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['userid'];
    
    // First, let's check if the user exists in the database
    $user_query = "SELECT * FROM assetusers WHERE id = '$id'";
    // Execute the query and fetch the result
    // ...

    // If the user exists, we can proceed to retrieve their assets
    if ($user_exists) {
        $asset_query = "SELECT assetname FROM asset WHERE id = '$id'";
        // Execute the query and fetch the result
        // ...

        // Display the assets received
        echo "<h2>Assets received:</h2>";
        while ($row = $result->fetch_assoc()) {
            echo $row['assetname'] . "<br>";
        }
    } else {
        echo "User does not exist.";
    }
}
?>