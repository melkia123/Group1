<!DOCTYPE html>
<html>
    <head>
        <title>login page</title>
        <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="../../css/logi.css">
        <script type="text/javascript">
            function validation(){
            var username=document.reg.username.value;
            var pass=document.reg.pass.value;
             if(username==""||username==null){
                document.getElementById('uspan').innerHTML="Please Enter Username";
                return false;
            }
            else if(pass==""||pword==null){
                document.getElementById('pspan').innerHTML="Please Enter Password";
                return false;
            }
        }
        </script>
         <style>
            .maiin{
            background-image:url(signup.jpg);    
            }
        </style>
    </head>
    <body>
        <!--menu section-->
        <div class="logoo">
<marquee behavior="scroll" direction="right"><h1><a href="http://localhost/assetmanagement" style="color:white;">WELLCOME TO LOGIN PAGE</a></h1></marquee>
        </div>
    <div class="maiin">
        <?php
        //if user logged
        if(isset($_SESSION['id'])){
            echo"You have already logged in";
        }else{
            //if user not login
        ?>
        <div class="box">
        <div class="form2">
<h2>Login page</h2>
<form method="POST" action="login.php" name="reg" onsubmit="return validation ();">
    <h5>Username</h5>
    <input type="text" name="username" ><br><span style="color:red;background-color:white;" id="uspan"></span>
    <h5>Password</h5>
    <input type="password" name="pass"><br><span style="color:red;background-color:white;" id="pspan"></span>
    <br><br>
    <input type="submit" name="login" value="login" >
</form>
</div>
</div>
<?php
    session_start();
        ?>
<?php
 }
 
 //login form logic
include('db.php');
if(isset($con)){
    if(isset($_POST['login'])){//if login button clicked
        $username=$_POST['username'];
        $password=md5($_POST['pass']);
        $sql="SELECT * FROM assetusers WHERE username='$username' and password='$password'";
        $res=mysqli_query($con,$sql);
        if(mysqli_num_rows($res)>0){
                        $exc=mysqli_fetch_array($res);
                        $_SESSION['id']=$exc['id'];
                        $_SESSION['fname']=$exc['fname'];
                        $_SESSION['lname']=$exc['lname'];
                        $_SESSION['email']=$exc['email'];
                        $_SESSION['username']=$exc['username'];
                        $_SESSION['password']=$exc['password'];
                        $_SESSION['role']=$exc['role'];
                        if($_SESSION['role']=='admin'){
                            header('location:../admin/dashboard.php');
                        }
                        else if($_SESSION['role']=='manager'){
                            header('location:../admin/manager.php');
                        }
                    else{
                        header('location:home.php');
                    }
                }else{
                    echo"invalid username and password";
            }
        }
    }
?>
</div>
    
    </div>
    <div class="foter">here is fo0ter</div>
    </body>
</html>