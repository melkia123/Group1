
<!DOCTYPE html>
    <head>
        <title>home page</title>
        <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="../../css/home.css">
        <?php
        session_start();
        ?>
        <style>
            .maiin{
    background-image: url(fixedaset.png);
            }
        </style>
    </head>
    <body>
    <div class="mennu">
        <ul>
            <?php
           if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/include/users/home.php">Home</a></li>
            <?php
           }else{
            ?>
            <li><a href="http://localhost/assetmanagement/index.php">Home</a></li>
            <?php
           }
           ?>
            <li><a href="http://localhost/assetmanagement/asset/index.php">Asset</a></li>
            <?php
            if(isset($_SESSION['id'])){
            ?>
            <li><a href="http://localhost/assetmanagement/asset/search.php">Search</a></li>
            <li><a href="http://localhost/assetmanagement/about.php">About</a></li>
            <li><a href="http://localhost/assetmanagement/contact.php">Contact</a></li>
            <li><a href="http://localhost/assetmanagement/include/admin/dashboard.php">Admin</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/logout.php">Logout</a></li>
            <?php
             }else{
                ?>
            <li><a href="http://localhost/assetmanagement/include/users/login.php">Login</a></li>
            <li><a href="http://localhost/assetmanagement/include/users/signup.php">Signup</a></li>
            </ul>
            </div>
            <?php
        }
        ?>
        </ul>
    </div>
    <div class="maiin">
        <marquee direction="left"><h1>WELLCOME TO WSU ASSET MANAGEMENT SYSTEM</h1></marquee>
    <?php
if(isset($_SESSION['id'])){
    echo"welcome".$_SESSION['fname'];
    ?>
    <?php
}else{
    header('location:index.php');
                    }
?>

    </div>
    <div class="foter">here is fo0ter</div>
    </body>
</html>
