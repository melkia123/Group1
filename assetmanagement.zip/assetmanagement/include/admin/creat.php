<?php

include('../users/db.php');

if(isset($_POST['creat']))
{
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $username =$_POST['username'];
    $password = md5($_POST['password']);
    $query = "INSERT INTO assetusers (fname,lname,email,username,password) VALUES ('$fname','$lname','$email','$username','$password')";    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        echo '<script> alert("Data Saved"); </script>';
        header('Location: assetusers.php');
    }
    else
    {
        echo '<script> alert("Data Not Saved"); </script>';
    }
}

?>